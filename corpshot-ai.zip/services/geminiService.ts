import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY is missing from environment variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

/**
 * Converts a File object to a Base64 string suitable for the Gemini API.
 */
export const fileToGenerativePart = async (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // Remove the data URL prefix (e.g., "data:image/jpeg;base64,")
      const base64Data = base64String.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

/**
 * Generates a corporate headshot based on an input image and a style description.
 */
export const generateCorporateHeadshot = async (
  imageBase64: string,
  mimeType: string,
  clothingDescription: string
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash-image';
    
    const prompt = `
      Edit this image to create a professional corporate headshot.
      The person should be wearing a ${clothingDescription}.
      The background should be a blurry, modern professional office environment with neutral tones.
      CRITICAL: Strictly preserve the person's face, facial features, skin tone, and identity. Do not alter the face.
      Adjust the lighting to be soft, studio-quality professional lighting.
      Ensure the image is high resolution and photorealistic.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            text: prompt,
          },
          {
            inlineData: {
              mimeType: mimeType,
              data: imageBase64,
            },
          },
        ],
      },
      config: {
        // We do not use responseMimeType here as we want the model to return an image part in the content
      }
    });

    // Parse response for image data
    if (response.candidates && response.candidates.length > 0) {
      const parts = response.candidates[0].content?.parts;
      if (parts) {
        for (const part of parts) {
          if (part.inlineData && part.inlineData.data) {
             // Return the base64 string directly. 
             // We will reconstruct the data URI in the component.
             return part.inlineData.data;
          }
        }
      }
    }

    throw new Error("No image data found in response");
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
