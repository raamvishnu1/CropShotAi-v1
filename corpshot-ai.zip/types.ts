export interface GeneratedImage {
  id: string;
  url: string;
  style: string;
  timestamp: number;
}

export interface GenerationConfig {
  color: string;
  styleName: string;
  promptModifier: string;
}

export enum AppState {
  IDLE = 'IDLE',
  UPLOADING = 'UPLOADING',
  GENERATING = 'GENERATING',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR'
}
