import React, { useCallback, useState } from 'react';
import { Upload, Image as ImageIcon, X } from 'lucide-react';
import { Button } from './Button';

interface UploadSectionProps {
  onFileSelect: (file: File) => void;
  selectedFile: File | null;
  onClear: () => void;
  isProcessing: boolean;
}

export const UploadSection: React.FC<UploadSectionProps> = ({ 
  onFileSelect, 
  selectedFile, 
  onClear,
  isProcessing 
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File size should be less than 5MB");
        return;
      }
      onFileSelect(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleClear = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    onClear();
  };

  return (
    <div className="w-full max-w-xl mx-auto mb-12">
      {!selectedFile ? (
        <div className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-200"></div>
          <div className="relative bg-white border-2 border-dashed border-slate-300 rounded-xl p-8 hover:border-blue-500 transition-colors text-center cursor-pointer">
            <input
              type="file"
              accept="image/png, image/jpeg, image/jpg"
              onChange={handleFileChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              disabled={isProcessing}
            />
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="p-4 bg-blue-50 rounded-full group-hover:bg-blue-100 transition-colors">
                <Upload className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Upload your photo</h3>
                <p className="text-slate-500 mt-1 text-sm">Drag and drop or click to browse</p>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-50 px-3 py-1 rounded-full">
                <ImageIcon className="h-3 w-3" />
                <span>JPG, PNG up to 5MB</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <h3 className="font-semibold text-slate-700 flex items-center gap-2">
              <ImageIcon className="h-4 w-4" />
              Original Image
            </h3>
            {!isProcessing && (
              <button 
                onClick={handleClear}
                className="text-slate-400 hover:text-red-500 transition-colors"
                title="Remove image"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
          <div className="p-6 flex flex-col items-center">
            <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-white shadow-xl mb-4">
              {previewUrl && (
                <img 
                  src={previewUrl} 
                  alt="Preview" 
                  className="w-full h-full object-cover"
                />
              )}
            </div>
            <p className="text-sm text-slate-500 mb-2">{selectedFile.name}</p>
          </div>
        </div>
      )}
    </div>
  );
};