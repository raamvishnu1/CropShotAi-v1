import React from 'react';
import { Download, ExternalLink } from 'lucide-react';
import { GeneratedImage } from '../types';

interface ResultCardProps {
  image: GeneratedImage;
}

export const ResultCard: React.FC<ResultCardProps> = ({ image }) => {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = image.url;
    link.download = `corpshot-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="group relative bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-200">
      <div className="aspect-[3/4] overflow-hidden bg-slate-100 relative">
        <img 
          src={image.url} 
          alt={image.style} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        
        {/* Overlay actions */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-2 backdrop-blur-[1px]">
          <button 
            onClick={handleDownload}
            className="p-3 bg-white text-slate-900 rounded-full hover:bg-blue-50 hover:text-blue-600 transition-colors transform translate-y-4 group-hover:translate-y-0 duration-300 shadow-lg"
            title="Download"
          >
            <Download className="h-5 w-5" />
          </button>
          <a 
            href={image.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-3 bg-white text-slate-900 rounded-full hover:bg-blue-50 hover:text-blue-600 transition-colors transform translate-y-4 group-hover:translate-y-0 duration-300 delay-75 shadow-lg"
            title="Open Full Size"
          >
            <ExternalLink className="h-5 w-5" />
          </a>
        </div>
      </div>
      
      <div className="p-4 bg-white border-t border-slate-100">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-blue-600 uppercase tracking-wider bg-blue-50 px-2 py-1 rounded-md">
            {image.style}
          </span>
        </div>
      </div>
    </div>
  );
};