import React from 'react';
import { Camera, Briefcase } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Camera className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 leading-none">CorpShot AI</h1>
              <p className="text-xs text-slate-500 font-medium">Professional Headshot Generator</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-sm text-slate-600">
            <span className="hidden sm:inline-flex items-center gap-1">
              <Briefcase className="h-4 w-4" />
              <span>Enterprise Grade</span>
            </span>
            <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full font-medium text-xs border border-blue-100">
              Gemini Powered
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};