import React, { useState } from 'react';
import { Header } from './components/Header';
import { UploadSection } from './components/UploadSection';
import { ResultCard } from './components/ResultCard';
import { Button } from './components/Button';
import { fileToGenerativePart, generateCorporateHeadshot } from './services/geminiService';
import { GeneratedImage, AppState, GenerationConfig } from './types';
import { Sparkles, AlertCircle, CheckCircle2 } from 'lucide-react';

// Configurations for the 6 variations
const GENERATION_CONFIGS: GenerationConfig[] = [
  { color: 'navy', styleName: 'Navy Blue Suit', promptModifier: 'dark navy blue business suit with a crisp white shirt and a subtle tie' },
  { color: 'navy', styleName: 'Navy Blue Blazer', promptModifier: 'modern navy blue professional blazer with a light blue shirt, open collar, no tie' },
  { color: 'navy', styleName: 'Deep Blue Executive', promptModifier: 'deep midnight blue executive suit, structured shoulders, silk tie' },
  { color: 'grey', styleName: 'Charcoal Grey Suit', promptModifier: 'charcoal grey tailored business suit, white shirt, grey silk tie' },
  { color: 'grey', styleName: 'Grey Blazer', promptModifier: 'light grey professional blazer, smart casual business look, white shirt' },
  { color: 'grey', styleName: 'Slate Grey Formal', promptModifier: 'slate grey formal three-piece suit, professional executive attire' },
];

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [results, setResults] = useState<GeneratedImage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setAppState(AppState.IDLE);
    setResults([]);
    setError(null);
  };

  const handleClear = () => {
    setSelectedFile(null);
    setAppState(AppState.IDLE);
    setResults([]);
    setError(null);
    setProgress(0);
  };

  const generateImages = async () => {
    if (!selectedFile) return;

    setAppState(AppState.GENERATING);
    setError(null);
    setResults([]);
    setProgress(0);

    try {
      const base64Data = await fileToGenerativePart(selectedFile);
      const mimeType = selectedFile.type;
      
      const newResults: GeneratedImage[] = [];
      let completedCount = 0;

      // We will process in batches of 3 to avoid overwhelming the browser/API or hitting rate limits too hard
      // Although gemini rate limits are usually RPM based, this helps UI responsiveness too.
      const batchSize = 3;
      
      for (let i = 0; i < GENERATION_CONFIGS.length; i += batchSize) {
        const batch = GENERATION_CONFIGS.slice(i, i + batchSize);
        
        // Execute batch in parallel
        const batchPromises = batch.map(async (config, index) => {
          try {
            const imageData = await generateCorporateHeadshot(base64Data, mimeType, config.promptModifier);
            return {
              id: crypto.randomUUID(),
              url: `data:image/png;base64,${imageData}`,
              style: config.styleName,
              timestamp: Date.now()
            } as GeneratedImage;
          } catch (err) {
            console.error(`Failed to generate variant ${config.styleName}`, err);
            return null;
          }
        });

        const batchResults = await Promise.all(batchPromises);
        
        // Filter out failures and add to results
        const validResults = batchResults.filter((r): r is GeneratedImage => r !== null);
        
        newResults.push(...validResults);
        
        // Update state with new results immediately so user sees progress
        setResults(prev => [...prev, ...validResults]);
        
        completedCount += batch.length;
        setProgress((completedCount / GENERATION_CONFIGS.length) * 100);
      }

      if (newResults.length === 0) {
        throw new Error("Failed to generate any images. Please try a clearer photo.");
      }

      setAppState(AppState.COMPLETE);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong during generation. Please try again.");
      setAppState(AppState.ERROR);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
        
        {/* Hero Section */}
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight mb-4">
            Transform your look instantly
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Upload a selfie and our AI will generate professional corporate headshots 
            in multiple styles, keeping your identity perfectly intact.
          </p>
        </div>

        {/* Input Area */}
        <div className="flex flex-col items-center justify-center">
          <UploadSection 
            onFileSelect={handleFileSelect}
            selectedFile={selectedFile}
            onClear={handleClear}
            isProcessing={appState === AppState.GENERATING}
          />

          {selectedFile && appState !== AppState.GENERATING && appState !== AppState.COMPLETE && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <Button 
                onClick={generateImages}
                className="px-8 py-3 text-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5"
                icon={<Sparkles className="w-5 h-5" />}
              >
                Generate Headshots
              </Button>
            </div>
          )}

          {/* Progress Bar */}
          {appState === AppState.GENERATING && (
            <div className="w-full max-w-md mt-4">
              <div className="flex items-center justify-between text-sm text-slate-600 mb-2">
                <span>Generating variations...</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div 
                  className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out" 
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <p className="text-center text-xs text-slate-400 mt-2">
                This usually takes about 15-30 seconds.
              </p>
            </div>
          )}

          {/* Error Message */}
          {appState === AppState.ERROR && error && (
            <div className="mt-6 p-4 bg-red-50 border border-red-100 rounded-lg flex items-start gap-3 text-red-700 max-w-md">
              <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
              <p className="text-sm">{error}</p>
            </div>
          )}
        </div>

        {/* Results Grid */}
        {(results.length > 0) && (
          <div className="mt-16 animate-in fade-in duration-700">
            <div className="flex items-center gap-3 mb-8 border-b border-slate-200 pb-4">
              <CheckCircle2 className="h-6 w-6 text-green-500" />
              <h3 className="text-2xl font-bold text-slate-900">Your Professional Headshots</h3>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {results.map((image) => (
                <ResultCard key={image.id} image={image} />
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}